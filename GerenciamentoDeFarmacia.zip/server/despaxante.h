#ifndef DESPAXANTE_H
#define DESPAXANTE_H
#include <iostream>
#include <string>
#include <nlohmann/json.hpp>

using namespace std;

string do_operation(string,int);
int package_id(string);

// Defina o mapeamento para os métodos


#endif