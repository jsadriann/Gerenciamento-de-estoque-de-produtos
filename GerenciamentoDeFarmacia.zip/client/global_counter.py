cont = 0

# Função para incrementar a variável global
def increment():
    global cont
    cont += 1
    return cont